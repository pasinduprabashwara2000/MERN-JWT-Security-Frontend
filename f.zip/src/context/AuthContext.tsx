import {createContext, useContext, useState, ReactNode} from "react";
import api from "../api/axios.ts"

interface User{
    id: string;
    name : string;
    email : string;
}