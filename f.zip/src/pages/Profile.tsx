import {useState, useEffect} from "react";
import api from "../api/axios"

const Profile = () => {
    const [user, setUser] = useState<User || null>(null);
}