import {useState} from "react";
import {Link} from "react-router-dom";

const Login = () => {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const handleClear = () => {
        setEmail("")
        setPassword("")
    }

    return (
        <div>
            <h2>Welcome Back</h2>
            <p>Login to your Account</p>

            <label>Email : </label>
            <input type="text" value={email} placeholder="Enter Your Email" onChange={(e)=> setEmail(e.target.value)}/>

            <label>Password : </label>
            <input type="text" value={password} placeholder="Enter Your Password" onChange={(e)=> setPassword(e.target.value)}/>

            <button>Login</button>
            <button onClick={handleClear}>Clear</button>

            <p>Don't have a account ? </p>
            <Link to="/register">Register</Link>

        </div>
    )

}

export default Login