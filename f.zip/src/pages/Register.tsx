import {useState} from "react";
import {Link} from "react-router-dom";

export const Register = () => {
    const [name, setName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const handleClear = () => {
        setName("")
        setEmail("")
        setPassword("")
    }

    const handleRegister = async () => {

        try {

            if (!name || !email || !password) {
                alert("All Fields Required")
                return
            }

        } catch (error) {

        }
    }

    return(
            <div>

                <h2>Create Account</h2>
                <p>Register to get Start</p>

                <label>Name : </label>
                <input type="text" value={name} placeholder="Enter Your Name" onChange={(e)=> setName(e.target.value)}/>

                <label>Email : </label>
                <input type="text" value={email} placeholder="Enter Your Email" onChange={(e)=> setEmail(e.target.value)}/>

                <label>Password : </label>
                <input type="password" value={password} placeholder="Enter Your Password" onChange={(e)=> setPassword(e.target.value)}/>

                <button onClick={handleRegister}>Register</button>
                <button onClick={handleClear}>Clear</button>

                <p>Already Have a Account ?</p>
                <Link to="/login">Login</Link>

            </div>
    )

}