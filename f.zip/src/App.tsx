import {BrowserRouter, Navigate, Route, Routes} from "react-router-dom";
import Login from "./pages/Login.tsx";
import {Register} from "./pages/Register.tsx";

function App() {
  return (
      <BrowserRouter>
          <Routes>
              <Route path="/" element={<Navigate to="/login" />} />

              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

          </Routes>
      </BrowserRouter>
  )
}

export default App
